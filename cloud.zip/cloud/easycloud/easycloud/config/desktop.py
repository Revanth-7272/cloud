from frappe import _


def get_data():
	return [
		{
			"module_name": "EasyCloud",
			"type": "module",
			"label": _("EasyCloud"),
		}
	]
