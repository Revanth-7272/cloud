app_name = "easycloud"
app_title = "EasyCloud"
app_publisher = "Kinnera"
app_description = "Production booking app for ERPNext v16"
app_email = "easycloud@example.com"
app_license = "mit"

required_apps = ["erpnext"]
