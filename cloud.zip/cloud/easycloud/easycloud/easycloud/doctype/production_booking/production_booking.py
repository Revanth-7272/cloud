# Copyright (c) 2026, Kinnera and contributors
# For license information, please see license.txt

from frappe.model.document import Document


class ProductionBooking(Document):
	pass
