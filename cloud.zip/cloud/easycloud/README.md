# EasyCloud

Custom Frappe app for ERPNext v16 with a **Production Booking** DocType.

## Features

- **Production Booking** DocType with:
  - Work Order (Link → Work Order)
  - Floor (Data)
  - Phase (Data)
  - Produced Quantity (Float)

## Requirements

- ERPNext v16 / Frappe v16
- [Frappe Bench](https://github.com/frappe/bench)

## Installation

```bash
cd $PATH_TO_YOUR_BENCH
bench get-app https://github.com/YOUR_USERNAME/easycloud --branch main
bench --site your-site.local install-app easycloud
bench migrate
```

## Development Setup (ERPNext v16)

On Ubuntu / WSL:

```bash
# Install uv and bench
curl -LsSf https://astral.sh/uv/install.sh | sh
source $HOME/.local/bin/env
uv tool install frappe-bench

# Initialize bench with Frappe v16
bench init --frappe-branch version-16 frappe-bench
cd frappe-bench

# Install ERPNext v16
bench get-app --branch version-16 erpnext

# Add this app
bench get-app /path/to/easycloud
bench new-site easycloud.local --admin-password admin
bench --site easycloud.local install-app erpnext
bench --site easycloud.local install-app easycloud
bench start
```

## License

MIT
