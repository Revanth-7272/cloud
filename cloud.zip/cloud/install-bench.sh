#!/usr/bin/env bash
set -euo pipefail

export PATH="$HOME/.local/bin:$PATH"

log() { echo "[$(date +%H:%M:%S)] $*"; }

log "=== Installing ERPNext v16 + easycloud (user: $USER) ==="

# uv + bench
if ! command -v uv >/dev/null 2>&1; then
  log "Installing uv..."
  curl -LsSf https://astral.sh/uv/install.sh | sh
  export PATH="$HOME/.local/bin:$PATH"
fi

if ! command -v bench >/dev/null 2>&1; then
  log "Installing frappe-bench..."
  uv tool install frappe-bench
  export PATH="$HOME/.local/bin:$PATH"
fi

BENCH_DIR="$HOME/frappe-bench"
CLOUD_APP="/mnt/c/Users/Kinnera/OneDrive/Desktop/cloud/easycloud"

if [ ! -d "$BENCH_DIR" ]; then
  log "Initializing Frappe bench (version-16)..."
  bench init --frappe-branch version-16 "$BENCH_DIR"
fi

cd "$BENCH_DIR"

if [ ! -d "apps/erpnext" ]; then
  log "Downloading ERPNext v16..."
  bench get-app --branch version-16 erpnext
fi

if [ ! -d "apps/easycloud" ]; then
  log "Adding easycloud app..."
  ln -s "$CLOUD_APP" apps/easycloud
fi

if [ ! -d "sites/easycloud.local" ]; then
  log "Creating site easycloud.local..."
  bench new-site easycloud.local \
    --mariadb-root-password admin \
    --admin-password admin \
    --no-mariadb-socket
  bench --site easycloud.local install-app erpnext
  bench --site easycloud.local install-app easycloud
  bench --site easycloud.local migrate
fi

log "=== Setup complete ==="
bench version
echo ""
echo "Start ERPNext:"
echo "  cd ~/frappe-bench && bench start"
echo "URL: http://localhost:8000"
echo "Login: Administrator / admin"
