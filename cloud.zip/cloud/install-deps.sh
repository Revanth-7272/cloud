#!/usr/bin/env bash
set -euo pipefail

export DEBIAN_FRONTEND=noninteractive

log() { echo "[$(date +%H:%M:%S)] $*"; }

log "=== Installing system dependencies (root) ==="

apt-get update -y
apt-get install -y \
  git python3-dev python3-pip python3-venv \
  redis-server mariadb-server mariadb-client \
  libmariadb-dev pkg-config \
  curl wget xvfb libfontconfig \
  wkhtmltopdf \
  nodejs npm

npm install -g yarn

# MariaDB config
if [ ! -f /etc/mysql/conf.d/frappe.cnf ]; then
  tee /etc/mysql/conf.d/frappe.cnf >/dev/null <<'EOF'
[mysqld]
character-set-client-handshake = FALSE
character-set-server = utf8mb4
collation-server = utf8mb4_unicode_ci
[mysql]
default-character-set = utf8mb4
EOF
fi

service mariadb restart || systemctl restart mariadb
service redis-server start || systemctl start redis-server

mysql -u root -e "ALTER USER 'root'@'localhost' IDENTIFIED BY 'admin'; FLUSH PRIVILEGES;" 2>/dev/null || \
  mysql -u root -e "SET PASSWORD FOR 'root'@'localhost' = PASSWORD('admin'); FLUSH PRIVILEGES;" 2>/dev/null || true

log "=== System dependencies installed ==="
