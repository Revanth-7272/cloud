#!/usr/bin/env bash
set -euo pipefail

export PATH="$HOME/.local/bin:$PATH"
export DEBIAN_FRONTEND=noninteractive

log() { echo "[$(date +%H:%M:%S)] $*"; }

log "=== ERPNext v16 setup on Ubuntu ==="

# System dependencies
if ! command -v mysql >/dev/null 2>&1; then
  log "Installing system packages (requires sudo)..."
  sudo apt-get update -y
  sudo apt-get install -y \
    git python3-dev python3-pip python3-venv \
    redis-server mariadb-server mariadb-client \
    libmariadb-dev pkg-config \
    curl wget xvfb libfontconfig \
    wkhtmltopdf \
    nodejs npm
  sudo npm install -g yarn
fi

# MariaDB config
if [ ! -f /etc/mysql/conf.d/frappe.cnf ]; then
  log "Configuring MariaDB..."
  sudo tee /etc/mysql/conf.d/frappe.cnf >/dev/null <<'EOF'
[mysqld]
character-set-client-handshake = FALSE
character-set-server = utf8mb4
collation-server = utf8mb4_unicode_ci
[mysql]
default-character-set = utf8mb4
EOF
  sudo systemctl restart mariadb || sudo service mariadb restart
  sudo mysql -u root -e "ALTER USER 'root'@'localhost' IDENTIFIED BY 'admin'; FLUSH PRIVILEGES;" 2>/dev/null || true
fi

# Redis
sudo systemctl start redis-server 2>/dev/null || sudo service redis-server start 2>/dev/null || true

# uv + bench
if ! command -v uv >/dev/null 2>&1; then
  log "Installing uv..."
  curl -LsSf https://astral.sh/uv/install.sh | sh
  export PATH="$HOME/.local/bin:$PATH"
fi

if ! command -v bench >/dev/null 2>&1; then
  log "Installing frappe-bench..."
  uv tool install frappe-bench
  export PATH="$HOME/.local/bin:$PATH"
fi

BENCH_DIR="$HOME/frappe-bench"
CLOUD_APP="/mnt/c/Users/Kinnera/OneDrive/Desktop/cloud/easycloud"

# Initialize bench
if [ ! -d "$BENCH_DIR" ]; then
  log "Initializing Frappe bench (version-16)..."
  bench init --frappe-branch version-16 "$BENCH_DIR"
fi

cd "$BENCH_DIR"

# ERPNext
if [ ! -d "apps/erpnext" ]; then
  log "Downloading ERPNext v16..."
  bench get-app --branch version-16 erpnext
fi

# EasyCloud app
if [ ! -d "apps/easycloud" ]; then
  log "Adding easycloud app..."
  if [ -d "$CLOUD_APP" ]; then
    ln -s "$CLOUD_APP" apps/easycloud
  else
    bench new-app easycloud --no-git
  fi
fi

# Site
if [ ! -d "sites/easycloud.local" ]; then
  log "Creating site easycloud.local..."
  bench new-site easycloud.local \
    --mariadb-root-password admin \
    --admin-password admin \
    --no-mariadb-socket
  bench --site easycloud.local install-app erpnext
  bench --site easycloud.local install-app easycloud
  bench --site easycloud.local migrate
fi

log "=== Setup complete ==="
bench version
echo ""
echo "Start ERPNext with:"
echo "  cd ~/frappe-bench && bench start"
echo "Open: http://localhost:8000  (login: Administrator / admin)"
